<?php
/**
 * The template for displaying search forms in Twenty Eleven
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>
	<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/finds' ) ); ?>">  
	    <label for="s"></label>  
	    <input type="text" name="query" id="s" facetly="on" />  
	    <input type="submit" name="submit" id="searchsubmit" value="Search" />  
	</form>  