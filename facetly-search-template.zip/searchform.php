<?php
/**
 * The template for displaying search forms for facetly
 *
 */
	if (!empty($_GET['query'])) {
		$query = stripslashes($_GET['query']);
		$query = htmlentities($query);
	} else {
		$query = '';
	}

	$common = get_option('facetly_settings');
	$key = $common['key'];
	$secret = $common['secret'];
	$server = $common['server'];
	$limit = $common['limit'];

 	$x = basename( site_url() );
	$x = str_replace($_SERVER['HTTP_HOST'], '', $x);
	if (!empty($x)) {
		$action = "/". $x. "/finds";
	} else {
		$action = "/finds";
	}

	$isfind = strpos($_SERVER['REQUEST_URI'], $action);
	if ( $isfind !== false && $isfind == 0 ) {
	  $action = "finds";
	}
?>
	<form method="get" id="searchform"  facetly_form="on" action="<?php echo $action; ?>">  
	    <label for="s"></label>  
	    <input type="text" name="query" id="s" facetly="on" value="<?php echo $query; ?>"/>  
	    <input type="submit" id="searchsubmit" value="Search" />
	    <input type="hidden" name="limit" id="edit-limit" value="<?php echo $limit; ?>">
	</form>  