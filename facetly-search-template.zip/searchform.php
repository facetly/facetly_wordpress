<?php
/**
 * The template for displaying search forms for facetly
 *
 */
	if (!empty($_GET['query'])) {
		$query = $_GET['query'];
	} else {
		$query = '';
	}

	$common = get_option('facetly_settings');
	$key = $common['key'];
	$secret = $common['secret'];
	$server = $common['server'];
	$limit = $common['limit'];

?>
	<form method="get" id="searchform"  facetly_form="on" action="finds">  
	    <label for="s"></label>  
	    <input type="text" name="query" id="s" facetly="on" value="<?php echo $query; ?>"/>  
	    <input type="submit" name="searchsubmit" id="searchsubmit" value="Search" />
	    <input type="hidden" name="limit" id="edit-limit" value="<?php echo $limit; ?>">
	</form>  