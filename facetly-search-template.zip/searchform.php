<?php
/**
 * The template for displaying search forms in Twenty Eleven
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 * @since Twenty Eleven 1.0
 */
?>
	<form method="get" id="searchform"  facetly_form="on" action="/finds">  
	    <label for="s"></label>  
	    <input type="text" name="query" id="s" facetly="on" />  
	    <input type="submit" name="searchsubmit" id="searchsubmit" value="Search" />  
	</form>  