<?php
/**
 * The template for displaying search forms in Twenty Ten
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>
	<form method="get" id="searchform" action="<?php echo esc_url( home_url( '/facetly-search' ) ); ?>">  
	    <label for="s"></label>  
	    <input type="text" name="query" id="s" facetly="on" />  
	    <input type="submit" name="submit" id="searchsubmit" value="Search" />  
	</form>    