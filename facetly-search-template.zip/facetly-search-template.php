<?php
	/**
	* Template Name: Facetly Search
	*/

get_header(); ?>

	<div id="container">
		<div id="content" role="main">
			<div id="facetly_result">
				<?php 
					echo do_shortcode("[facetly_search output=results]");
				?>			
			</div>
		</div>
	</div>

	<div id="primary" class="widget-area" role="complementary">
			<?php get_search_form(); ?>
			<div id="facetly_facet">
				<?php 
					echo do_shortcode("[facetly_search output=facets]");
				?>
			</div>
		</div>
<?php get_footer(); ?>