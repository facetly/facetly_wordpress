<?php
	/**
	* Template Name: Facetly Search
	*/

get_header(); ?>

	<div id="container">
		<div id="content" role="main">
			<div id="facetly_result">
				<?php 
					$search = facetly_search();
					echo $search->results;
				?>			
			</div>
		</div><!-- #content -->
	</div><!-- #container -->

	<div id="primary" class="widget-area" role="complementary">
			<?php get_search_form(); ?>
			<div id="facetly_facet">
				<?php 
				$instance = array("title" => "Facetly Widget",);
				$args = array("title" => "", "before_title" => "<h2>", "after_title" => "</h2>");
				$sb = new Facetly_Widget();
				$sb->widget($args,$instance);

				//echo $search->facets; ?>
			</div>
		</div>
<?php get_footer(); ?>